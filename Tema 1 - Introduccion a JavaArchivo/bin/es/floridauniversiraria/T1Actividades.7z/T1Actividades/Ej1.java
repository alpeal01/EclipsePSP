package es.floridauniversiraria.T1Actividades;

public class Ej1 {
	public static void main(String[] args) {
		
		int num1 = 2;
		int num2 = 4;
		int res = num1 + num2;
		
		System.out.println(res);
		
	}
}
