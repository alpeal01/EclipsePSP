package es.floridauniversiraria.T1Actividades;

public class Hola {

	public static void sayHello() {
		
		System.out.println("Hola mundo");
		
	}
	
	
}
