package es.floridauniversiraria.T1Actividades;

import java.util.Scanner;

public class Ej2 {
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		String nom = sc.nextLine();
		
		System.out.println("Hola "+ nom);
		
		sc.close();
		
	}

}
