package es.floridauniversiraria.T1Actividades;

//Genera archivos ejecutables (.JAR) de algunos ejercicios y ejecútalos por línea de comandos

public class Ej30 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
